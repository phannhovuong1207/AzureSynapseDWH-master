"SET PATH = C:\Program Files\OpenJDK\jdk-14.0.1\bin" | cmd ;
"cd C:\ajmeter\apache-jmeter-5.2.1\bin\" | cmd ;
"C:\ajmeter\apache-jmeter-5.2.1\bin\jmeter -n -t C:\ajmeter\apache-jmeter-5.2.1\bin\EastLoadDefinition.jmx" | cmd
